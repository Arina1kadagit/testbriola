<?php

echo '<div id="call" class="mobile_call">
			<p><a href="tel:+73843200299">200-299</a></p>
			</div>';


echo '<div id="goodbye">
					<p><a href="logout.php">Выйти</a> из системы.</p>
				</div>
			</div>';


?>