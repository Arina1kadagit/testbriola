<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<!-- <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no"> -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1.0, minimum-scale=1.0, maximum-scale=1.0">
	<?php echo '<script src="js/mc.js?ver='.date('Y-m-d H:i:s').'" type="text/javascript" defer=""></script>'; ?>
	<?php echo '<script src="js/lzyimj.js?ver='.date('Y-m-d H:i:s').'" type="text/javascript" defer=""></script>'; ?>
	<?php echo '<script src="js/scr.js?ver='.date('Y-m-d H:i:s').'" type="text/javascript" defer=""></script>'; ?>
	<?php // echo '<script src="js/resize.js?ver='.date('Y-m-d H:i:s').'" type="text/javascript" defer=""></script>'; ?>
	<title>ССК</title>
	<?php echo "<link href=\"css/style.css?ver=".date('Y-m-d H:i:s')."\" media=\"screen\" rel=\"stylesheet\">"; ?>
	<!--<link rel="icon" type="image/png" href="favicon.png" />-->
	<link rel="icon" type="image/gif" href="favicon.png" />
	<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.min.css'>
</head>