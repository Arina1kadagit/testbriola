<?php

	// Тестовая база
	// Константы базы данных сайта
	/*
	define("DB_SERVER", "192.168.95.229");
	define("DB_NAME", "agit");
	define("DB_USER", "root");
	define("DB_PASS", 'Hs2#Le3$Nt5$');
	*/
	// Константы 1С
	/*
	define("BASE_1C_ADDRESS", 'http://192.168.95.229/FreshSCopy');
	define("BASE_1C_AUTH", 'Basic 0JDQtNC80LjQvdC40YHRgtGA0LDRgtC+0YA6aGpkdGg=');
	*/
		
	// Тестовая база
	// Константы базы данных сайта
	define("DB_SERVER", "192.168.95.229");
	define("DB_NAME", "agit");
	define("DB_USER", "root2");
	define("DB_PASS", 'Hs2#Le3$Nt5$');
	// Константы 1С
	/*
	define("BASE_1C_ADDRESS", 'http://fresh.nvadm.ru/TradeWeb');
	define("BASE_1C_AUTH", 'Basic 0JDQtNC80LjQvdC40YHRgtGA0LDRgtC+0YA6aGpkdGg=');
	*/



	// Рабочая база
	// Константы базы данных сайта
	/*
	define("DB_SERVER", "localhost");
	define("DB_NAME", "u1773497_db");
	define("DB_USER", "u1773497_usr");
	define("DB_PASS", '1sZXA2oG4Aer82TE');
	*/
	// Константы 1С
	define("BASE_1C_ADDRESS", 'http://uslada.nvadm.ru/Baza1C');
	define("BASE_1C_AUTH", 'Basic 0JDQtNC80LjQvdC40YHRgtGA0LDRgtC+0YA6aGpkdGg=');
	
?>